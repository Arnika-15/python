from flask import *
app = Flask(__name__)
@app.route("/homepage")
def homepage():
	return render_template("homepage.html")
	
@app.route("/admin")
def admin():
	return render_template("admin.html")

@app.route("/user")
def user():
	return render_template("user.html")

@app.route("/userregister")
def userregister():
	return render_template("userregister.html")

@app.route("/adminregister")
def adminregister():
	return render_template("adminregister.html")

@app.route("/formcountry")
def formcountry():
	return render_template("formcountry.html")

@app.route("/forminstitution")
def forminstitution():
	return render_template("forminstitution.html")

@app.route("/formresearch")
def formresearch():
	return render_template("formresearch.html")

@app.route("/formtitle")
def formtitle():
	return render_template("formtitle.html")

@app.route("/formyear")
def formyear():
	return render_template("formyear.html")

@app.route("/search")
def search():
	return render_template("search.html")







if __name__=='__main__':
	app.run(debug = True)
