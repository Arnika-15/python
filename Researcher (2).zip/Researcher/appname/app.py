from flask import *
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
engine=create_engine('postgresql://postgres:arnika@localhost/research')

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:arnika@localhost/research'
app.config['SECRET_KEY'] = "random string"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

@app.route("/index")
def index():
	return render_template("index.html")

@app.route("/homepage")
def homepage():
	return render_template("homepage.html")
	
@app.route("/adminlogin")
def adminlogin():
	return render_template("adminlogin.html")

@app.route("/userlogin")
def userlogin():
	return render_template("userlogin.html")

@app.route("/userregister")
def userregister():
	return render_template("userregister.html")

@app.route("/adminregister")
def adminregister():
	return render_template("adminregister.html")

@app.route("/formcountry")
def formcountry():
	return render_template("formcountry.html")

@app.route("/forminstitution")
def forminstitution():
	return render_template("forminstitution.html")

@app.route("/formresearch")
def formresearch():
	return render_template("formresearch.html")

@app.route("/formtitle")
def formtitle():
	return render_template("formtitle.html")

@app.route("/formyear")
def formyear():
	return render_template("formyear.html")

@app.route("/projectdetails")
def projectdetails():
	return render_template("project_details.html")

@app.route("/message")
def message():
	return render_template("message.html")


@app.route("/search")
def search():
	return render_template("search.html")

@app.route('/adminlogin_check',methods= ["GET", "POST"])
def adminlogin_check():
	POST_USERNAME=str(request.form['Username'])
	POST_PASSWORD=str(request.form['Password'])
	Username = request.form['Username']
	session['Username']=Username
	
	Session = sessionmaker(bind = engine)
	s = Session()
	query = s.query(adminregister).filter(adminregister.username.in_([POST_USERNAME]),adminregister.password.in_([POST_PASSWORD]))
	result=query.first()
	
	if result:
		session['loggin_in'] = True 
		return redirect(url_for('formcountry'))
		return render_template("formcountry.html")
	else:
		flash('wrong password')
		return redirect(url_for('adminlogin'))
		return render_template('adminlogin.html')
		

@app.route('/userlogin_check',methods= ["GET", "POST"])
def userlogin_check():
	POST_USERNAME=str(request.form['Username'])
	POST_PASSWORD=str(request.form['Password'])
	Username = request.form['Username']
	session['Username']=Username
	
	Session = sessionmaker(bind = engine)
	s = Session()
	query = s.query(userregister).filter(userregister.username.in_([POST_USERNAME]),userregister.password.in_([POST_PASSWORD]))
	result=query.first()
	
	if result:
		session['loggin_in'] = True 
		return redirect(url_for('search'))
		return render_template("search.html")
	else:
		flash('wrong password')
		return redirect(url_for('userlogin'))
		return render_template('userlogin.html')


class adminregister(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	name=db.Column(db.String)
	email=db.Column(db.String)
	username=db.Column(db.String)
	password=db.Column(db.String)
	confirm=db.Column(db.String)
	
	def __init__(self,name,email,username,password,confirm):
		self.name=name
		self.email=email
		self.username=username
		self.password=password
		self.confirm=confirm
		
	@app.route("/adminregister_db",methods=["GET","POST"])
	def adminregister_db():
		id=db.Column('admin_id',db.Integer,primary_key=True)
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['confirm']:
				flash("Error")
			else:
				admin=adminregister(request.form['name'],request.form['email'],request.form['username'],request.form['password'],request.form['confirm'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('adminlogin'))
		return render_template("adminlogin.html")

class userregister(db.Model):
	id=db.Column('user_id',db.Integer,primary_key=True)
	name=db.Column(db.String)
	email=db.Column(db.String)
	username=db.Column(db.String)
	password=db.Column(db.String)
	confirm=db.Column(db.String)
	
	def __init__(self,name,email,username,password,confirm):
		self.name=name
		self.email=email
		self.username=username
		self.password=password
		self.confirm=confirm
		
	@app.route("/userregister_db",methods=["GET","POST"])
	def userregister_db():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['confirm']:
				flash("Error")
			else:
				user=userregister(request.form['name'],request.form['email'],request.form['username'],request.form['password'],request.form['confirm'])
				db.session.add(user)
				db.session.commit()
			return redirect(url_for('userlogin'))
		return render_template("userlogin.html")

class formcountry(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	country=db.Column(db.String)
	city=db.Column(db.String)
	
	def __init__(self,country,city):
		self.country=country
		self.city=city
		
	@app.route("/formcountry_db",methods=["GET","POST"])
	def formcountry_db():
		if request.method == 'POST':
			if not request.form['country'] or not request.form['city']:
				flash("Error")
			else:
				admin=formcountry(request.form['country'],request.form['city'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('formresearch'))
		return render_template("formresearch.html")

class formresearch(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	researcher_name=db.Column(db.String)
	country=db.Column(db.String)
	city=db.Column(db.String)
	
	def __init__(self,researcher_name,country,city):
		self.researcher_name=researcher_name
		self.country=country
		self.city=city
		
	@app.route("/formresearch_db",methods=["GET","POST"])
	def formresearch_db():
		if request.method == 'POST':
			if not request.form['researcher_name'] or not request.form['country'] or not request.form['city']:
				flash("Error")
			else:
				admin=formresearch(request.form['researcher_name'],request.form['country'],request.form['city'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('forminstitution'))
		return render_template("forminstitution.html")
		

class forminstitution(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	institution=db.Column(db.String)
	researcher_name=db.Column(db.String)
	country=db.Column(db.String)
	city=db.Column(db.String)
	
	def __init__(self,institution,researcher_name,country,city):
		self.institution=institution
		self.researcher_name=researcher_name
		self.country=country
		self.city=city
		
	@app.route("/forminstitution_db",methods=["GET","POST"])
	def forminstitution_db():
		if request.method == 'POST':
			if not request.form['institution'] or not request.form['researcher_name'] or not request.form['country'] or not request.form['city']:
				flash("Error")
			else:
				admin=forminstitution(request.form['institution'],request.form['researcher_name'],request.form['country'],request.form['city'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('formtitle'))
		return render_template("formtitle.html")
		
class formtitle(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	title=db.Column(db.String)
	researcher_name=db.Column(db.String)
	graduate=db.Column(db.String)
	institution=db.Column(db.String)
	
	def __init__(self,title,researcher_name,graduate,institution):
		self.title=title
		self.researcher_name=researcher_name
		self.graduate=graduate
		self.institution=institution
		
	@app.route("/formtitle_db",methods=["GET","POST"])
	def formtitle_db():
		if request.method == 'POST':
			if not request.form['title'] or not request.form['researcher_name'] or not request.form['graduate'] or not request.form['institution']:
				flash("Error")
			else:
				admin=formtitle(request.form['title'],request.form['researcher_name'],request.form['graduate'],request.form['institution'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('formyear'))
		return render_template("formyear.html")
		
class formyear(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	records=db.Column(db.String)
	researcher_name=db.Column(db.String)
	title=db.Column(db.String)
	year_from=db.Column(db.String)
	to=db.Column(db.String)
	
	def __init__(self,records,researcher_name,title,year_from,to):
		self.records=records
		self.researcer_name=researcher_name
		self.title=title
		self.year_from=year_from
		self.to=to
		
	@app.route("/formyear_db",methods=["GET","POST"])
	def formyear_db():
		if request.method == 'POST':
			if not request.form['records'] or not request.form['researcher_name'] or not request.form['title'] or not request.form['year_from'] or not request.form['to']:
				flash("Error")
			else:
				admin=formyear(request.form['records'],request.form['researcher_name'],request.form['title'],request.form['year_from'],request.form['to'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('projectdetails'))
		return render_template("project_details.html")

class projectdetails(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	researcher_name=db.Column(db.String)
	project_title=db.Column(db.String)
	project_description=db.Column(db.String)
	country=db.Column(db.String)
	city=db.Column(db.String)
	institution=db.Column(db.String)
	graduate=db.Column(db.String)
	project_duration=db.Column(db.String)
	
	def __init__(self,researcher_name,project_title,project_description,country,city,institution,graduate,project_duration):
		self.researcher_name=researcher_name
		self.project_title=project_title
		self.project_description=project_description
		self.country=country
		self.city=city
		self.institution=institution
		self.graduate=graduate
		self.project_duration=project_duration
	@app.route("/projectdetails_db",methods=["GET","POST"])
	def projectdetails_db():
		if request.method == 'POST':
			if not request.form['researcher_name'] or not request.form['project_title'] or not request.form['project_description'] or not request.form['country'] or not request.form['city'] or not request.form['institution'] or not request.form['graduate'] or not request.form['project_duration']:
				flash("Error")
			else:
				admin=projectdetails(request.form['researcher_name'],request.form['project_title'],request.form['project_description'],request.form['country'],request.form['city'],request.form['institution'],request.form['graduate'],request.form['project_duration'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('message'))
		return render_template("message.html")

if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)



