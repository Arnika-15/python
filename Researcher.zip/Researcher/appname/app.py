from flask import *
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
engine=create_engine('postgresql://postgres:arnika@localhost/research')

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:arnika@localhost/research'
app.config['SECRET_KEY'] = "random string"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

@app.route("/index")
def index():
	return render_template("index.html")

@app.route("/homepage")
def homepage():
	return render_template("homepage.html")
	
@app.route("/adminlogin")
def adminlogin():
	return render_template("adminlogin.html")

@app.route("/userlogin")
def userlogin():
	return render_template("userlogin.html")

@app.route("/userregister")
def userregister():
	return render_template("userregister.html")

@app.route("/adminregister")
def adminregister():
	return render_template("adminregister.html")

@app.route("/formcountry")
def formcountry():
	return render_template("formcountry.html")

@app.route("/forminstitution")
def forminstitution():
	return render_template("forminstitution.html")

@app.route("/formresearch")
def formresearch():
	return render_template("formresearch.html")

@app.route("/formtitle")
def formtitle():
	return render_template("formtitle.html")

@app.route("/formyear")
def formyear():
	return render_template("formyear.html")

@app.route("/projectdetails")
def projectdetails():
	return render_template("project_details.html",formresearch=formresearch.query.all(),forminstitution=forminstitution.query.all(),formtitle=formtitle.query.all(),formyear=formyear.query.all())

@app.route("/message")
def message():
	return render_template("message.html")

@app.route("/feedback")
def feedback():
	return render_template("feedback.html")

@app.route("/search")
def search():
	return render_template("search.html")

@app.route("/display")
def display():
	return render_template("display.html")

@app.route("/userfeedback")
def userfeedback():
	return render_template("userfeedback.html", feedback=feedback.query.all())

@app.route("/contact")
def contact():
	return render_template("contact.html")
	
@app.route("/report")
def report():
	return render_template("report.html", projectdetails=projectdetails.query.all())

@app.route("/display2")
def display2():
	return render_template("display2.html")

@app.route("/searchby")
def searchby():
	return render_template("searchby.html")

@app.route("/projectdetails1")
def projectdetails1():
	return render_template("project_details1.html",formresearch=formresearch.query.all(),forminstitution=forminstitution.query.all(),formtitle=formtitle.query.all(),formyear=formyear.query.all(),formcountry=formcountry.query.all(),projectdetails=projectdetails.query.all())

@app.route('/login',methods=['POST','GET'])
def login():
	if request.method=='POST':
		user=request.form['Institution']
		return redirect(url_for('success',name=user))
	else:
		user=request.form['Institution']
		return redirect(url_for('success',name=user))
		
@app.route('/drag/<name>')
def success(name):
	return render_template('display.html',projectdetails1=projectdetails1.query.filter_by(institution='%s'%name))





@app.route('/login1',methods=['POST','GET'])
def login1():
	if request.method=='POST':
		user=request.form['researcher_name']
		return redirect(url_for('success1',name=user))
	else:
		user=request.form['researcher_name']
		return redirect(url_for('success1',name=user))
		
@app.route('/dragresearcher/<name>')
def success1(name):
	return render_template('display2.html',projectdetails1=projectdetails1.query.filter_by(researcher_name='%s'%name))







@app.route('/adminlogin_check',methods= ["GET", "POST"])
def adminlogin_check():
	POST_USERNAME=str(request.form['Username'])
	POST_PASSWORD=str(request.form['Password'])
	Username = request.form['Username']
	session['Username']=Username
	
	Session = sessionmaker(bind = engine)
	s = Session()
	query = s.query(adminregister).filter(adminregister.username.in_([POST_USERNAME]),adminregister.password.in_([POST_PASSWORD]))
	result=query.first()
	
	if result:
		session['loggin_in'] = True 
		return redirect(url_for('formcountry'))
		return render_template("formcountry.html")
	else:
		flash('wrong password')
		return redirect(url_for('adminlogin'))
		return render_template('adminlogin.html')
		

@app.route('/userlogin_check',methods= ["GET", "POST"])
def userlogin_check():
	POST_USERNAME=str(request.form['Username'])
	POST_PASSWORD=str(request.form['Password'])
	Username = request.form['Username']
	session['Username']=Username
	
	Session = sessionmaker(bind = engine)
	s = Session()
	query = s.query(userregister).filter(userregister.username.in_([POST_USERNAME]),userregister.password.in_([POST_PASSWORD]))
	result=query.first()
	
	if result:
		session['loggin_in'] = True 
		return redirect(url_for('search'))
		return render_template("search.html")
	else:
		flash('wrong password')
		return redirect(url_for('userlogin'))
		return render_template('userlogin.html')


class adminregister(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	name=db.Column(db.String)
	email=db.Column(db.String)
	username=db.Column(db.String)
	password=db.Column(db.String)
	confirm=db.Column(db.String)
	
	def __init__(self,name,email,username,password,confirm):
		self.name=name
		self.email=email
		self.username=username
		self.password=password
		self.confirm=confirm
		
	@app.route("/adminregister_db",methods=["GET","POST"])
	def adminregister_db():
		id=db.Column('admin_id',db.Integer,primary_key=True)
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['confirm']:
				flash("Error")
			else:
				admin=adminregister(request.form['name'],request.form['email'],request.form['username'],request.form['password'],request.form['confirm'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('adminlogin'))
		return render_template("adminlogin.html")

class userregister(db.Model):
	id=db.Column('user_id',db.Integer,primary_key=True)
	name=db.Column(db.String)
	email=db.Column(db.String)
	username=db.Column(db.String)
	password=db.Column(db.String)
	confirm=db.Column(db.String)
	
	def __init__(self,name,email,username,password,confirm):
		self.name=name
		self.email=email
		self.username=username
		self.password=password
		self.confirm=confirm
		
	@app.route("/userregister_db",methods=["GET","POST"])
	def userregister_db():
		if request.method == 'POST':
			if not request.form['name'] or not request.form['email'] or not request.form['username'] or not request.form['password'] or not request.form['confirm']:
				flash("Error")
			else:
				user=userregister(request.form['name'],request.form['email'],request.form['username'],request.form['password'],request.form['confirm'])
				db.session.add(user)
				db.session.commit()
			return redirect(url_for('userlogin'))
		return render_template("userlogin.html")

class formcountry(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	country=db.Column(db.String)
	city=db.Column(db.String)
	
	def __init__(self,country,city):
		self.country=country
		self.city=city
		
	@app.route("/formcountry_db",methods=["GET","POST"])
	def formcountry_db():
		if request.method == 'POST':
			if not request.form['country'] or not request.form['city']:
				flash("Error")
			else:
				admin=formcountry(request.form['country'],request.form['city'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('formresearch'))
		return render_template("formresearch.html")

class formresearch(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	researcher_name=db.Column(db.String)
	
	
	def __init__(self,researcher_name):
		self.researcher_name=researcher_name
		
		
	@app.route("/formresearch_db",methods=["GET","POST"])
	def formresearch_db():
		if request.method == 'POST':
			if not request.form['researcher_name']:
				flash("Error")
			else:
				admin=formresearch(request.form['researcher_name'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('forminstitution'))
		return render_template("forminstitution.html")
		

class forminstitution(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	institution=db.Column(db.String)
	
	def __init__(self,institution):
		self.institution=institution
		
	@app.route("/forminstitution_db",methods=["GET","POST"])
	def forminstitution_db():
		if request.method == 'POST':
			if not request.form['institution']:
				flash("Error")
			else:
				admin=forminstitution(request.form['institution'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('formtitle'))
		return render_template("formtitle.html")
		
class formtitle(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	title=db.Column(db.String)
	
	def __init__(self,title):
		self.title=title
		
	@app.route("/formtitle_db",methods=["GET","POST"])
	def formtitle_db():
		if request.method == 'POST':
			if not request.form['title']:
				flash("Error")
			else:
				admin=formtitle(request.form['title'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('formyear'))
		return render_template("formyear.html")
					

class formyear(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	duration=db.Column(db.String)
	
	def __init__(self,duration):
		self.duration=duration
		
	@app.route("/formyear_db",methods=["GET","POST"])
	def formyear_db():
		if request.method == 'POST':
			if not request.form['duration']:
				flash("Error")
			else:
				admin=formyear(request.form['duration'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('projectdetails'))
		return render_template("project_details.html")



class projectdetails(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	researcher_name=db.Column(db.String)
	institution=db.Column(db.String)
	title=db.Column(db.String)
	project_duration=db.Column(db.String)
	abstract=db.Column(db.String)
	graduate=db.Column(db.String)
	
	
	def __init__(self,researcher_name,institution,title,project_duration,abstract,graduate):
		self.researcher_name=researcher_name
		self.institution=institution
		self.title=title
		self.project_duration=project_duration
		self.abstract=abstract
		self.graduate=graduate
	@app.route("/projectdetails_db",methods=["GET","POST"])
	def projectdetails_db():
		if request.method == 'POST':
			if not request.form['researcher_name'] or not request.form['institution'] or not request.form['title'] or not request.form['project_duration'] or not request.form['abstract'] or not request.form['graduate']:
				flash("Error")
			else:
				admin=projectdetails(request.form['researcher_name'],request.form['institution'],request.form['title'],request.form['project_duration'],request.form['abstract'],request.form['graduate'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('projectdetails1'))
		return render_template("project_details1.html")


class projectdetails1(db.Model):
	id=db.Column('admin_id',db.Integer,primary_key=True)
	researcher_name=db.Column(db.String)
	country=db.Column(db.String)
	institution=db.Column(db.String)
	title=db.Column(db.String)
	project_duration=db.Column(db.String)
	abstract=db.Column(db.String)
	wdone=db.Column(db.String)
	wdtwo=db.Column(db.String)
	wdthree=db.Column(db.String)
	wdfour=db.Column(db.String)
	wdfive=db.Column(db.String)
	graduate=db.Column(db.String)
	
	
	def __init__(self,researcher_name,country,institution,title,project_duration,abstract,wdone,wdtwo,wdthree,wdfour,wdfive,graduate):
		self.researcher_name=researcher_name
		self.country=country
		self.institution=institution
		self.title=title
		self.project_duration=project_duration
		self.abstract=abstract
		self.wdone=wdone
		self.wdtwo=wdtwo
		self.wdthree=wdthree
		self.wdfour=wdfour
		self.wdfive=wdfive
		self.graduate=graduate
		
	@app.route("/projectdetails1_db",methods=["GET","POST"])
	def projectdetails1_db():
		if request.method == 'POST':
			if not request.form['researcher_name'] or not request.form['country'] or not request.form['institution'] or not request.form['title'] or not request.form['project_duration'] or not request.form['abstract'] or not request.form['wdone'] or not request.form['wdtwo'] or not request.form['wdthree'] or not request.form['wdfour'] or not request.form['wdfive'] or not request.form['graduate']:
				flash("Error")
			else:
				admin=projectdetails1(request.form['researcher_name'],request.form['country'],request.form['institution'],request.form['title'],request.form['project_duration'],request.form['abstract'],request.form['wdone'],request.form['wdtwo'],request.form['wdthree'],request.form['wdfour'],request.form['wdfive'],request.form['graduate'])
				db.session.add(admin)
				db.session.commit()
			return redirect(url_for('message'))
		return render_template("message.html")



class feedback(db.Model):
	id=db.Column('user_id',db.Integer,primary_key=True)
	first_name=db.Column(db.String)
	last_name=db.Column(db.String)
	feedback=db.Column(db.String)
	
	def __init__(self,first_name,last_name,feedback):
		self.first_name=first_name
		self.last_name=last_name
		self.feedback=feedback
		
	@app.route("/feedback_db",methods=["GET","POST"])
	def feedback_db():
		if request.method == 'POST':
			if not request.form['first_name'] or not request.form['last_name'] or not request.form['feedback']:
				flash("Error")
			else:
				user=feedback(request.form['first_name'],request.form['last_name'],request.form['feedback'])
				db.session.add(user)
				db.session.commit()
			return redirect(url_for('search'))
		return render_template("search.html")
		


if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)



